							</td>
							<td class='menuColumn' valign='top'>
								
								<?php dispMenu(1); ?>
								
							</td>
						</tr>				
					</table>
	
	
				</td>
				<td class='right-side'></td>
			</tr>
			<tr>
				<td class='bottom-left-corner'>&nbsp;</td>
				<td class='bottom-side'></td>
				<td class='bottom-right-corner'>&nbsp;</td>
			</tr>
		</table>
		<div class='push'></div>
	</div>

	
	<div class='footerDiv'>
		<p align='center' style='padding-top: 20px; margin-bottom: 0px; padding-bottom: 0px'><b>Powered By: <a href='http://www.bluethrust.com' target='_blank'>Bluethrust Clan Scripts v4</a></b></p>
		<p align='center' style='margin: 0px; padding: 0px'>&copy; Copyright <?php echo date("Y"); ?> <?php echo $websiteInfo['clanname']; ?></p>
	</div>
	
	
	<?php include($prevFolder."themes/include_footer.php"); ?>
	
</body>
</html>