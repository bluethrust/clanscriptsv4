<?php
include($prevFolder."themes/wbgs/_logindisplay.php");
include($prevFolder."themes/include_header.php");
include($prevFolder."themes/wbgs/_menus.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo $PAGE_NAME.$CLAN_NAME; ?></title>
		<link rel='stylesheet' type='text/css' href='<?php echo $MAIN_ROOT; ?>themes/wbgs/style.css'>
			<link rel='stylesheet' type='text/css' href='<?php echo $MAIN_ROOT; ?>themes/wbgs/btcs4.css'>
			<link rel='stylesheet' type='text/css' href='<?php echo $MAIN_ROOT; ?>themes/wbgs/jqueryui/jquery-ui-1.9.2.custom.min.css'>
			<script type='text/javascript' src='<?php echo $MAIN_ROOT; ?>js/jquery-1.6.4.min.js'></script>
			<script type='text/javascript' src='<?php echo $MAIN_ROOT; ?>js/jquery-ui-1.8.17.custom.min.js'></script>
			<script type='text/javascript' src='<?php echo $MAIN_ROOT; ?>js/main.js'></script>
			<script type='text/javascript' src='<?php echo $MAIN_ROOT; ?>js/imageslider.js'></script>
			<?php if(isset($EXTERNAL_JAVASCRIPT))
			        echo $EXTERNAL_JAVASCRIPT; ?>
	</head>
	<body>
	<div id='toolTip'></div>
	<div id='toolTipWidth'></div>

	
	
	<!-- Start Logo Section -->
		<div class='logoDiv'><img src='<?php echo $MAIN_ROOT; ?>themes/wbgs/images/logo.png'><br><img src='<?php echo $MAIN_ROOT; ?>themes/wbgs/images/logo2.png'></div>
		<div class='left-orange-line'><img src='<?php echo $MAIN_ROOT; ?>themes/wbgs/images/layout/left-line.png'></div>
		<div class='right-orange-line'><img src='<?php echo $MAIN_ROOT; ?>themes/wbgs/images/layout/right-line.png'></div>
	<!-- End Logo Section -->
	
	
	<div class='mainSiteContainer'>
		<table class='mainLayoutTable'>
			<tr>
				<td class='top-left-corner'>&nbsp;</td>
				<td class='top-side'></td>
				<td class='top-right-corner'>&nbsp;</td>
			</tr>
			<tr>
				<td class='left-side'></td>
				<td class='mainContentBox' valign='top'>
	
					
					
					<table class='mainInnerTable'>
						<tr>
							<td class='menuColumn' valign='top'>
								
								<?php dispMenu(0); ?>
								
							</td>
							<td class='contentColumn' valign='top'>
							
							<?php
							
							// Get UTC TIME
							$utcTime = time();
						
							// Clock Display
							$displaydate = date("l, F j, Y"); 

							$easternDate = new DateTime(date("Y-m-d"), new DateTimeZone('America/New_York'));
							$eastOffset = $easternDate->getOffset();
							$eastTime = ($utcTime+$eastOffset);
							$eastHour = gmdate("G", $eastTime);
							$eastMinutes = gmdate("i", $eastTime);

							$centralDate = new DateTime(date("Y-m-d"), new DateTimeZone('America/Chicago'));
							$centralOffset = $centralDate->getOffset();
							$centralTime = ($utcTime+$centralOffset);
							$centralHour = gmdate("G", $centralTime);
							$centralMinutes = gmdate("i", $centralTime);

							$mountainDate = new DateTime(date("Y-m-d"), new DateTimeZone('America/Denver'));
							$mountainOffset = $mountainDate->getOffset();
							$mountainTime = ($utcTime+$mountainOffset);
							$mountainHour = gmdate("G", $mountainTime);
							$mountainMinutes = gmdate("i", $mountainTime);

							$pacificDate = new DateTime(date("Y-m-d"), new DateTimeZone('America/Los_Angeles'));
							$pacificOffset = $pacificDate->getOffset();
							$pacificTime = ($utcTime+$pacificOffset);
							$pacificHour = gmdate("G", $pacificTime);
							$pacificMinutes = gmdate("i", $pacificTime);
							
							echo "
							<div style='text-align: center'>
								<div class='gradientBox' style='text-align: left; width: 99%; margin: 0px auto 2px auto; padding: 3px; height: 14px; font-weight: bold; font-size: 11px'>
								".$displaydate."
							</div>
							</div>
							<div class='main' style='margin-bottom: 15px'>
								<p align='center' style='margin: 0px; padding: 0px'>
									<span class='main' style='color: lime; font-weight: bold'>Eastern Time: <span id='showEasternTime'></span></span> || <span class='main' style='color: gold; font-weight: bold'>Central Time: <span id='showCentralTime'></span></span> || <span class='main' style='color: #EE82EE; font-weight: bold'>Mountain Time: <span id='showMountainTime'></span></span> || <span class='main' style='color: #B0E0E6; font-weight: bold'>Pacific Time: <span id='showPacificTime'></span></span>
								</p>
							</div>
							<script type='text/javascript'>
								displayClock(".$eastHour.", ".$eastMinutes.", 'showEasternTime');
								displayClock(".$centralHour.", ".$centralMinutes.", 'showCentralTime');
								displayClock(".$mountainHour.", ".$mountainMinutes.", 'showMountainTime');
								displayClock(".$pacificHour.", ".$pacificMinutes.", 'showPacificTime');
							</script>
							";
						
						?>
							
							